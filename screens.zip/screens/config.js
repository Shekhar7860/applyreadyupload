import firebase from 'react-native-firebase';

// var config = {
//     apiKey: "AIzaSyCAfW864JF7lz2blcAiLRZ1Ginz1V9ZEy4",
//     authDomain: "react-native-crud-10c7c.firebaseapp.com",
//     databaseURL: "https://react-native-crud-10c7c.firebaseio.com",
//     projectId: "react-native-crud-10c7c",
//     storageBucket: "react-native-crud-10c7c.appspot.com",
//     messagingSenderId: "893224975013"
//   };
//   let app = firebase.initializeApp(config);
  //export const db = firebase.database();